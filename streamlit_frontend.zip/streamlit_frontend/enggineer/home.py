import streamlit as st

def main():
    st.markdown('# Welcome to Car Dealership and Servicing')
    st.divider()
    st.markdown('### Your Roles:Enggineer ')
    st.markdown('- Manage Service Requests')
    st.markdown('- Provide Cost Estimate')
    st.markdown('- Update Service Progress')
    st.markdown('- Alert Pickup')
    
if __name__ == "__main__":
    main()