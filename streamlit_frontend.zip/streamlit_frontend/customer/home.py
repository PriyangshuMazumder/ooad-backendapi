import streamlit as st

def main():
    st.markdown('# Welcome to Car Dealership and Servicing')
    st.divider()
    st.markdown('### Our Services for you .. ')
    st.markdown('- Browse Cars Catalog')
    st.markdown('- Schedule Testdrive')
    st.markdown('- Purchase Car')
    st.markdown('- Schedule Car Servicing')
    st.markdown('- Update Car Servicing')
    st.markdown('- View Service Status')
if __name__ == "__main__":
    main()